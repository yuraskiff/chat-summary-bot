#!/bin/bash
# Startup script for Render.com
python main.py
